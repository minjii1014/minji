package www.dream.com.party.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;
import lombok.NoArgsConstructor;
import www.dream.com.framework.model.CommonMngInfoVO;

@Data
@NoArgsConstructor
public class PartyVO extends CommonMngInfoVO implements Serializable {
	private long id;
	private String name;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date birthDate;
	
	/* 연관 정보 정의 부분 */
	private List<ContactPointVO> listContactPoint;
	private List<AuthorityVO> listAuthority;
	
	public PartyVO(long id) {
		this.id = id;
	}
}
