package www.dream.com.party.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PostVO extends PartyVO {
	private String descript;
	
	public PostVO(long id) {
		super(id);
	}
}
