package www.dream.com.party.model;

import java.io.Serializable;

import lombok.Data;
import www.dream.com.framework.model.CommonMngInfoVO;

@Data
public class ContactPointVO extends CommonMngInfoVO implements Serializable {
	private String typeName;
	private String contactPoint;
}
