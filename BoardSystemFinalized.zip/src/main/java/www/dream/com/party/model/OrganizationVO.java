package www.dream.com.party.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrganizationVO extends PartyVO {
	public OrganizationVO(long id) {
		super(id);
	}
}
