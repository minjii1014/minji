package www.dream.com.party.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PersonVO extends PartyVO {
	private String loginId;
	private String password;
	private boolean gender;

	public PersonVO(long id) {
		super(id);
	}
}
