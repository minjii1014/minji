package www.dream.com.party.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class AuthorityVO implements Serializable {
	private String authority;
}
