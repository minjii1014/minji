package www.dream.com.party.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import www.dream.com.party.model.ContactPointTypeVO;
import www.dream.com.party.model.PartyVO;
import www.dream.com.party.model.PersonVO;

public interface PartyMapper {
	public List<ContactPointTypeVO> listContactPointType();
	
	public List<PartyVO> selectAllParty(String partyType);
	public List<PartyVO> selectAllPartyWithContactPoint(String partyType);

	/* PersonVO 전용 서비스 영역 */
	public PersonVO findPersonByLoginId(@Param("loginId") String loginId);
	public boolean changePwd(PersonVO person);

	public boolean chkIdDup(String newId);
}
