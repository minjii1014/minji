package www.dream.com.party.model;

import lombok.Data;

@Data
public class ContactPointTypeVO {
	private String typeName;
	private String descript;
	private String validatingRegExp;
	private String superName;
}
