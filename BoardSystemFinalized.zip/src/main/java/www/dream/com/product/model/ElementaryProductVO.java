package www.dream.com.product.model;

public class ElementaryProductVO extends ProductVO {
	public ElementaryProductVO(Long id) {
		super(id);
	}

	@Override
	public String toString() {
		return "ElementaryProductVO [" + super.toString() + "]";
	}
}
