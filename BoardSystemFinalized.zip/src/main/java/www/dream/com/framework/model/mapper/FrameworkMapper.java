package www.dream.com.framework.model.mapper;

public interface FrameworkMapper {
}
