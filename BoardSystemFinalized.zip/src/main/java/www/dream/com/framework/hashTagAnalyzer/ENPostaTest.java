package www.dream.com.framework.hashTagAnalyzer;

import java.util.List;

import kr.co.shineware.nlp.posta.en.core.EnPosta;

public class ENPostaTest {

	public static void main(String[] args) {
		//https://shineware.tistory.com/entry/ENPOSTA-ver-05
		EnPosta posta = new EnPosta();
		posta.load("C:\\StsWorkspace\\libs\\model_0.5");

		// 사용자 사전 추가
		//posta.appendUserDic("dic.user");

		posta.buildFailLink();

		List<String> resultList = posta.analyze(
				"내가 사랑하는 사람은 누구일까? Launch a new institute at the University of Washington to conduct independent, rigorous evaluations of health programs worldwide.");
		for (String result : resultList) {
			System.out.println(result);
		}
	}
}
