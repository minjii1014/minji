package www.dream.com.board.model.mapper;

import java.util.List;

import www.dream.com.board.model.BoardVO;

public interface BoardMapper {
	public List<BoardVO> selectAllBoard();
}
