package www.dream.com.board.model;

import lombok.Data;

@Data
public class BoardVO {
	private long id;
	private String name;
	
//	public BoardVO(long id, String name) {
//		super();
//		this.id = id;
//		this.name = name;
//	}
}
