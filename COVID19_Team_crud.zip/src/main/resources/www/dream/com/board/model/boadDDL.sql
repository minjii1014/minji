drop table T_Board;
drop sequence seq4Board_id;


create sequence seq4Board_id;
create table T_Board(
	id			numeric(8,0) primary key,
	name		varchar2(20)
);

insert into T_Board(id, name)
  values(seq4Board_id.nextval, 'COVID-19 Map');
insert into T_Board(id, name)
  values(seq4Board_id.nextval, '��������');
insert into T_Board(id, name)
  values(seq4Board_id.nextval, '���� �Խ���');